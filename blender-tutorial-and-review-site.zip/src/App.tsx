import { useMemo, useState } from "react";
import { motion } from "framer-motion";

const practiceModes = [
  {
    id: "blocking",
    label: "Blocking",
    time: "5 min",
    note: "Roughly shape your object with simple forms before touching details.",
  },
  {
    id: "lighting",
    label: "Lighting",
    time: "7 min",
    note: "Use one key light and one fill light, then move the camera until the scene reads clearly.",
  },
  {
    id: "render",
    label: "Render",
    time: "3 min",
    note: "Increase samples only after composition works. Fast iteration beats perfect settings early on.",
  },
];

export default function App() {
  const [activeMode, setActiveMode] = useState(practiceModes[0].id);

  const selectedMode = useMemo(
    () => practiceModes.find((mode) => mode.id === activeMode) ?? practiceModes[0],
    [activeMode],
  );

  return (
    <div className="bg-zinc-950 text-zinc-100">
      <header className="relative flex min-h-screen items-center overflow-hidden px-6 py-20 sm:px-10 lg:px-20">
        <motion.img
          initial={{ scale: 1.08, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          src="https://images.unsplash.com/photo-1640552435388-a54879e72b28?auto=format&fit=crop&w=1800&q=80"
          alt="3D artist workspace with a model open in Blender"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950/90 via-zinc-900/75 to-zinc-900/55" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative mx-auto w-full max-w-5xl"
        >
          <p className="text-lg font-semibold tracking-[0.22em] text-orange-300">BLENDER SPRINT</p>
          <h1 className="mt-5 max-w-3xl text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
            Best Short Blender Tutorial for Beginners
          </h1>
          <p className="mt-5 max-w-2xl text-base text-zinc-200 sm:text-lg">
            If you only have 15 minutes, this is the one tutorial I recommend and why it works better than most
            long beginner playlists.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#tutorial"
              className="bg-orange-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-orange-400"
            >
              Watch The Tutorial
            </a>
            <a
              href="#thoughts"
              className="border border-zinc-200/60 px-6 py-3 text-sm font-semibold text-zinc-100 transition hover:bg-zinc-100 hover:text-zinc-950"
            >
              Read My Thoughts
            </a>
          </div>
        </motion.div>
      </header>

      <main>
        <motion.section
          id="tutorial"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-5xl px-6 py-20 sm:px-10"
        >
          <h2 className="text-3xl font-semibold text-white sm:text-4xl">The Short Tutorial I Recommend</h2>
          <p className="mt-4 max-w-3xl text-zinc-300">
            Start with "Blender Beginner Tutorial in 15 Minutes" by Ryan King Art. It moves quickly, covers
            navigation, modeling, materials, lighting, and render output in one flow.
          </p>
          <div className="mt-8 overflow-hidden border border-zinc-700">
            <iframe
              className="aspect-video w-full"
              src="https://www.youtube.com/embed/At9qW8ivJ4Q"
              title="Blender Beginner Tutorial in 15 Minutes"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          </div>
        </motion.section>

        <motion.section
          id="thoughts"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-5xl px-6 pb-24 sm:px-10"
        >
          <h2 className="text-3xl font-semibold text-white sm:text-4xl">My Thoughts</h2>
          <p className="mt-4 max-w-3xl text-zinc-300">
            Great beginner tutorials do three things: they keep your hands moving, avoid advanced theory too early,
            and finish with a result you can be proud of. This one nails those points. It is short enough to repeat,
            and repeating is where Blender skill actually builds.
          </p>

          <div className="mt-10 border border-zinc-700 bg-zinc-900/60 p-6">
            <p className="text-sm font-semibold tracking-wide text-orange-300">15-MINUTE PRACTICE LOOP</p>
            <div className="mt-4 flex flex-wrap gap-3">
              {practiceModes.map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setActiveMode(mode.id)}
                  className={`px-4 py-2 text-sm font-medium transition ${
                    activeMode === mode.id
                      ? "bg-orange-500 text-white"
                      : "border border-zinc-600 text-zinc-200 hover:border-zinc-300"
                  }`}
                >
                  {mode.label}
                </button>
              ))}
            </div>

            <motion.div
              key={selectedMode.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="mt-5"
            >
              <p className="text-xl font-semibold text-white">{selectedMode.time}</p>
              <p className="mt-2 max-w-2xl text-zinc-300">{selectedMode.note}</p>
            </motion.div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}
